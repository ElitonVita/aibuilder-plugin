# AIBuilder — Prebuilt constructions pack / Pacote de construções pré-modeladas

These are extra constructions for the AIBuilder Paper plugin. They are **not** in the plugin jar: extract them into the server's `prebuilts/` folder and the plugin picks them up automatically.

Estas são construções extras para o plugin AIBuilder (Paper). Elas **não** vêm dentro do jar: extraia para a pasta `prebuilts/` do servidor e o plugin as carrega automaticamente.

## English

### Install (server operator, 2 minutes)

1. Stop the server (or keep it running — the plugin reloads models on demand).
2. Copy the `.json` files from this pack into:
   `plugins/AIBuilder/prebuilts/`
   (do **not** keep them in a subfolder — the plugin reads one JSON per file from that folder, top level only)
3. Run `/builder reload`.
4. Run `/builder prebuilt list` — each construction shows up with its `id`, title, and the area size it needs.
5. In game: mark an area with the diamond shovel, then `/builder <builder-name> prebuilt <id>` and confirm. The plugin tells you the required area (x/y/z + volume + block count) before you build.

### Requirements and limits

- AIBuilder `1.0.0` or newer, Paper server, Java 25.
- Files are skipped if the server already has an `id` in use (built-in or another file); invalid JSON files are reported in the server log and ignored.
- Hard limits: max 256 user models per server (`prebuilt.max-user-models`), file size up to `construction.max-file-bytes` (default 64 MiB), height up to 100 blocks.
- **Full solid blocks only** — doors, beds, stairs, slabs, torches, carpets, plants, and fluids are not supported by the executor.
- Coordinates are relative to the marked area's minimum corner; you choose where the construction appears.

## Português

### Instalação (operador do servidor, 2 minutos)

1. Pare o servidor (ou deixe rodando — o plugin recarrega os modelos sob demanda).
2. Copie os arquivos `.json` deste pacote para:
   `plugins/AIBuilder/prebuilts/`
   (não deixe dentro de uma subpasta — o plugin lê um JSON por arquivo dessa pasta, somente no nível superior)
3. Rode `/builder reload`.
4. Rode `/builder prebuilt list` — cada construção aparece com seu `id`, título e o tamanho da área necessário.
5. No jogo: marque uma área com a pá de diamante, depois `/builder <nome-do-construtor> prebuilt <id>` e confirme. O plugin informa a área necessária (x/y/z + volume + quantidade de blocos) antes de construir.

### Requisitos e limites

- AIBuilder `1.0.0` ou mais recente, servidor Paper, Java 25.
- Arquivos são ignorados se o servidor já tiver um `id` em uso (built-in ou outro arquivo); JSONs inválidos são registrados no log do servidor e ignorados.
- Limites: máximo 256 modelos de usuário por servidor (`prebuilt.max-user-models`), tamanho de arquivo até `construction.max-file-bytes` (padrão 64 MiB), altura até 100 blocos.
- **Somente blocos sólidos completos** — portas, camas, escadas, lajes, tochas, tapetes, plantas e líquidos não são suportados pelo executor.
- As coordenadas são relativas ao canto mínimo da área marcada; você escolhe onde a construção aparece.

## License / Licença

MIT License — Copyright (c) 2026 elitonvita.
